<?php
namespace Swoole;

interface Observer
{
    public function update($observer);
}
