<?php
$mongo['master'] = array(
    'host' => '127.0.0.1',
);
return $mongo;