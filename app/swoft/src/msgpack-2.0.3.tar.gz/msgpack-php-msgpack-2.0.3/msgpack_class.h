
#ifndef MSGPACK_CLASS_H
#define MSGPACK_CLASS_H

#define MSGPACK_CLASS_OPT_PHPONLY -1001

void msgpack_init_class();

#endif
