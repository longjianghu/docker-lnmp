/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: f2f525e0d154673c4369cd9a3bf6c84141fbfdc8 */

ZEND_BEGIN_ARG_INFO_EX(arginfo_tideways_xhprof_enable, 0, 0, 0)
	ZEND_ARG_INFO(0, options)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_tideways_xhprof_disable, 0, 0, 0)
ZEND_END_ARG_INFO()
