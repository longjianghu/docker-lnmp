# 5.0.2

- [#90](https://github.com/tideways/php-xhprof-extension/issues/90): Add packaging for PHP 7.4

# 5.0.1

- [#86](https://github.com/tideways/php-xhprof-extension/pull/86): Fix bug in Apple/MacOS timer code that prevented wall time measurements from working.
