<?php
namespace Swoole\Exception;

class Response extends \Exception
{

}
