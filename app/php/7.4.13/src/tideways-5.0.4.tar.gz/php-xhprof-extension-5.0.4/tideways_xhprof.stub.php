<?php

/**
 * @param int|null $options
 * @return void
 *
 * @generate-legacy-arginfo
 */
function tideways_xhprof_enable($options = null) {}
/**
 * @return array
 *
 * @generate-legacy-arginfo
 */
function tideways_xhprof_disable() {}
